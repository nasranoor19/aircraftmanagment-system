package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.Entity.Passenger;
import com.example.demo.Repository.PassengerRepository;

@RestController
@RequestMapping("passenger")
public class PassengerController {
     
  @Autowired
  PassengerRepository passRep;
 ///doing the get map// this one retrieves all passengers
  @GetMapping
  public List<Passenger> getPassengers(){
  return passRep.findAll();
}

  @GetMapping("/{passengerid}")
  public Optional<Passenger> getPassenger(@PathVariable Long id){
   return passRep.findById(id);
  }
  ///now will do the post map



  @PutMapping("/updatePassenger")
    public ResponseEntity<String> updateFlight(@RequestBody Passenger passenger){
        Long id = passenger.getId();
        if(passRep.existsById(id)) {
            passRep.save(passenger);
            return ResponseEntity.ok("Updated");
        } else {
          return ResponseEntity.notFound().build();
        }
    }

  @PostMapping("/savePassenger")
      public ResponseEntity<String> savePassenger(@RequestBody Passenger passenger){
      passenger.setId(null);
      passRep.save(passenger);
      return ResponseEntity.ok("Saved");
      }


  @DeleteMapping("/deletePassenger/{id}")
  public ResponseEntity<String> deleteFlight(@PathVariable Long id){
      if(passRep.existsById(id)) {
          passRep.deleteById(id);
          return ResponseEntity.ok("Deleted");
      } else {
          return ResponseEntity.notFound().build();
      }
  }


}