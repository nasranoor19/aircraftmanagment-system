package com.example.demo.Entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="aircraft")
public class Aircraft {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id; 
    String model;
    Integer capacity;
    @OneToMany(mappedBy = "aircraft")
    List<Flight> flights;

    public Aircraft() { }

    public Aircraft(String model , Integer capacity) {
        this.model = model;
        this.capacity = capacity;
        flights = new ArrayList<>();
    }

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public int getCapacity() {
        return capacity;
    }
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    public List<Flight> getFlights() {
        return flights;
    }
    public void setFlights(List<Flight> flight) {
        this.flights = flight;
    }
    public void addFlight(Flight f){
        flights.add(f);
    }
    public void deleteFlight(Flight f){
        flights.remove(f);
    }
    

}
