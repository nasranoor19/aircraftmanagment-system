package com.example.demo;


import com.example.demo.Entity.Aircraft;
import com.example.demo.Entity.Flight;
import com.example.demo.Entity.Passenger;
import com.example.demo.Repository.AirCraftRepository;
import com.example.demo.Repository.FlightRepository;
import com.example.demo.Repository.PassengerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	
	@Bean
	public CommandLineRunner commandLineRunner(AirCraftRepository ar, FlightRepository fr, PassengerRepository pr) {
		return (runner) -> {

			Aircraft a1 = new Aircraft("Boeing", 180);
			Aircraft a2 = new Aircraft("Star", 200);
			Aircraft a3 = new Aircraft("Fulesk", 150);

			Flight f1 = new Flight(10, "12.40", "14.00", a1);
			Flight f2 = new Flight(11, "13.40", "15.00", a2);

			Passenger p1 = new Passenger("Ulvi", "Mercan", "14A");
			Passenger p2 = new Passenger("Nasra", "Nooooor", "15A");
			Passenger p3 = new Passenger("Ayse", "Fatma", "16A");
			Passenger p4 = new Passenger("Mehmet", "Hasan", "17A");
			Passenger p5 = new Passenger("Hajar", "Said", "18A");

			ar.save(a1);
			ar.save(a2);
			ar.save(a3);

			f1.addPassenger(p1);
			f1.addPassenger(p2);
			f1.addPassenger(p4);
			f2.addPassenger(p3);
			f2.addPassenger(p5);

			fr.save(f1);
			fr.save(f2);

			pr.save(p1);
			pr.save(p2);
			pr.save(p3);
			pr.save(p4);
			pr.save(p5);

		};
	}

}
