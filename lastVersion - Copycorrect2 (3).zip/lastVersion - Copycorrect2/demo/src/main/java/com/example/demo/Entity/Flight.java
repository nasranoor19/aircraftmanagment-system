package com.example.demo.Entity;

import java.util.ArrayList;
import java.util.List;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="flight")
public class Flight {
     //su27
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    @Column
    
    int flightNumber;
   

    @Column
    String departTime;
    String arrivalTime;

    @ManyToMany(mappedBy = "flights")
    List<Passenger> passengers;

    @ManyToOne
    Aircraft aircraft;
    
    public Flight() {}

    public Flight(int flightNumber , String departTime , String arrivalTime , Aircraft aircraft) {
        this.flightNumber = flightNumber;
        this.departTime = departTime;
        this.arrivalTime = arrivalTime;
        this.aircraft=aircraft;
        aircraft.addFlight(this);
        passengers = new ArrayList<>();
    }

    public List<Passenger> getPassengers() {
        return passengers;
    }
    public void setPassengers(List<Passenger> passengers) {
        this.passengers = passengers;
    }
    public void addPassenger(Passenger p){
        if(!passengers.contains(p)) {
            passengers.add(p);
            p.addFlight(this);
        }
    }
    public void deletePassenger(Passenger p){
        passengers.remove(p);
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public int getFlightNumber() {
        return flightNumber;
    }
    public void setFlightNumber(int flightNumber) {
        this.flightNumber = flightNumber;
    }
    public String getDepartTime() {
        return departTime;
    }
    public void setDepartTime(String departTime) {
        this.departTime = departTime;
    }
    public String getArrivalTime() {
        return arrivalTime;
    }
    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }
    public Aircraft getAircraft() {
        return aircraft;
    }
    public void setAircraft(Aircraft aircraft) {
        this.aircraft = aircraft;
    }

}
