package com.example.demo.Controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Flight;
import com.example.demo.Entity.Passenger;
import com.example.demo.Repository.FlightRepository;
import com.example.demo.Repository.PassengerRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;





@RestController
@RequestMapping("flight")

public class FlightController {
    

    @Autowired
    FlightRepository flightRep;
    @Autowired
    PassengerRepository passRep;


    @GetMapping
	public List<Flight> getFlights(){
		return flightRep.findAll();
	}

    @GetMapping("{id}")
    public Optional<Flight> getFlight(@PathVariable Long id){
     return flightRep.findById(id);
    }
    
    @PostMapping("/saveflight")
      public ResponseEntity<String> saveAircraft(@RequestBody Flight flight){
      flight.setId(null);
      flightRep.save(flight);
      return ResponseEntity.ok("Saved");
      }



   @PutMapping("/updateFligtht")
    public ResponseEntity<String> updateFlight(@RequestBody Flight flight){
        Long id = flight.getId();
        if(flightRep.existsById(id)) {
            flightRep.save(flight);
            return ResponseEntity.ok("Updated");
        } else {
          return ResponseEntity.notFound().build();
        }
    }


    @DeleteMapping("/deleteFlight/{id}")
    public ResponseEntity<String> deleteFlight(@PathVariable Long id){
        if(flightRep.existsById(id)) {
            Flight flight = flightRep.findById(id).get();
            List<Passenger> passengers = flight.getPassengers();
            for(Passenger p : passengers){
                p.deleteFlight(flight);
                passRep.save(p);
            }

            flightRep.deleteById(id);
            return ResponseEntity.ok("Deleted");
        } else {
            return ResponseEntity.notFound().build();
        }
    } 


	

}
