package com.example.demo.Entity;

import java.util.ArrayList;
import java.util.List;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

import jakarta.persistence.Table;

@Entity
@Table(name="passenger")
public class Passenger {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    @Column
    String name;
    String surname;
    String seatNum;

  //so here we are checking how many flights each passenger is taking in this specific flight
// therefore the relationship is many to many cuz many passenger can take many flights as possible
    @ManyToMany
    List<Flight> flights;


    
    public Passenger() {}

    public Passenger(String name , String surname , String seatNum) {
        this.name = name;
        this.surname = surname;
        this.seatNum = seatNum;
        flights = new ArrayList<>();
    }

    public List<Flight> getFlights() {
        return flights;
    }
    public void setFlights(List<Flight> flights) {
        this.flights = flights;
    }
    public long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getSurname() {
        return surname;
    }
    public void setSurname(String surname) {
        this.surname = surname;
    }
    public String getSeatNum() {
        return seatNum;
    }
    public void setSeatNum(String seatNum) {
        this.seatNum = seatNum;
    }
    public void addFlight(Flight f){
        if(!flights.contains(f)) {
            flights.add(f);
            f.addPassenger(this);
        }
    }
    public void deleteFlight(Flight f){
        flights.remove(f);
    }
    



  

}
