package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Aircraft;

public interface AirCraftRepository extends JpaRepository<Aircraft,Long>{
    
}
