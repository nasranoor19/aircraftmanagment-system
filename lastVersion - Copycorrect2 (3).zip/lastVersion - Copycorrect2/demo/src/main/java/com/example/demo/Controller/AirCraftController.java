package com.example.demo.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Aircraft;
import com.example.demo.Entity.Flight;
import com.example.demo.Entity.Passenger;
import com.example.demo.Repository.AirCraftRepository;
import com.example.demo.Repository.FlightRepository;
import com.example.demo.Repository.PassengerRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("aircraft")
public class AirCraftController {
    
  @Autowired
  AirCraftRepository aircraftRep;
  @Autowired
  FlightRepository flightRep;
  @Autowired
  PassengerRepository passRep;

  


    @GetMapping
    public ResponseEntity<String> getAircraft() {
        List<Aircraft> aircrafts = aircraftRep.findAll();
        String result = "";
        for(Aircraft a : aircrafts){
            result += "ID: " + a.getId() + " Model: " + a.getModel() + " Capacity: " + a.getCapacity() + "<br> Flights: ";

            for(Flight f : a.getFlights()){
                result += "ID: " + f.getId() + "<br>Flight Number: " + f.getFlightNumber() + "<br>Departure Time:" + f.getDepartTime() + "<br>Arrival Time: " + f.getArrivalTime() + "<br>";
                result += "Passengers: <br>";
                for(Passenger p : f.getPassengers()){
                    result += "ID: " + p.getId() + " - First Name: " + p.getName() + " Last Name: " + p.getSurname() + "Seat Number: " + p.getSeatNum() + "<br>";
                }
                result += "<br>";
            }
            result += "------------ <br>";
        }
        return ResponseEntity.ok(result);
    }

    @GetMapping("{id}")
    public Optional<Aircraft> getAircraftId(@PathVariable Long id){
      return aircraftRep.findById(id);
    }

    @PostMapping("/saveAircraft")
    public ResponseEntity<String> saveAircraft(@RequestBody Aircraft aircraft){
    aircraft.setId(null);
    aircraftRep.save(aircraft);
    return ResponseEntity.ok("Saved");
    }


      @PutMapping("/updateAircraft")
      public ResponseEntity<String> updateAircraft(@RequestBody Aircraft aircraft){
        Long id = aircraft.getId();
        if(aircraftRep.existsById(id)) {
            aircraftRep.save(aircraft);
            return ResponseEntity.ok("Updated");
        } else {
          return ResponseEntity.notFound().build();
        }
      }

      @DeleteMapping("/deleteAircraft/{id}")
      public ResponseEntity<String> deleteAircraft(@PathVariable Long id){
        if(aircraftRep.existsById(id)) {
            Aircraft aircraft = aircraftRep.findById(id).get();
            List<Flight> flights = aircraft.getFlights();

            for(Flight f : flights){
               List<Passenger> passengers = f.getPassengers();
               for(Passenger p : passengers) {
                   p.deleteFlight(f);
                   passRep.save(p);
               }

               flightRep.deleteById(id);
            }

            aircraftRep.deleteById(id);
            return ResponseEntity.ok("Deleted");
        } else {
          return ResponseEntity.notFound().build();
        }
      }



}
